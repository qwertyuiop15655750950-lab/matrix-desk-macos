#!/bin/bash
set -euo pipefail
DEVICE_ROOT="$(cd "$(dirname "$0")" && pwd)"
DEVICE_PYTHON="${MATRIX_DEVICE_PYTHON:-$DEVICE_ROOT/venv/bin/python}"
if [[ ! -x "$DEVICE_PYTHON" ]]; then
  echo "请先按 README 创建独立 Python 环境，或设置 MATRIX_DEVICE_PYTHON 指向已有环境。"
  exit 2
fi
cd "$DEVICE_ROOT"
exec "$DEVICE_PYTHON" "$DEVICE_ROOT/run.py"
