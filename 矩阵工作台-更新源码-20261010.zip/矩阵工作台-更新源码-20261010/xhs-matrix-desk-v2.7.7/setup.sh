#!/bin/bash
# 小红书矩阵工作台 - Mac 一键安装脚本
set -e
cd "$(dirname "$0")"

echo "=== 1/3 创建虚拟环境 ==="
python3 -m venv venv

echo "=== 2/3 安装依赖（playwright / pillow / pytest / pywebview） ==="
./venv/bin/pip install --quiet --upgrade pip
./venv/bin/pip install --quiet -r requirements.txt

echo "=== 3/3 下载浏览器内核（约 150MB） ==="
./venv/bin/python -m playwright install chromium

echo ""
echo "安装完成！启动方式："
echo "  ./venv/bin/python run.py          # 新版 Web 界面"
echo "  ./venv/bin/python run.py --tk     # 经典界面"
