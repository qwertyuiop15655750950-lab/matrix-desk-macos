#!/bin/bash
set -euo pipefail
PACKAGE_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALL_DIR="${MATRIX_INSTALL_DIR:-$HOME/Applications/多平台矩阵工作台}"
if [[ -f "$PACKAGE_DIR/run.py" ]]; then INSTALL_DIR="$PACKAGE_DIR"; fi
if [[ ! -x "$INSTALL_DIR/venv/bin/python" ]]; then
  echo "尚未找到运行环境，请先双击「安装.command」。"
  exit 2
fi
exec "$INSTALL_DIR/venv/bin/python" "$INSTALL_DIR/启动器.py" "$@"
