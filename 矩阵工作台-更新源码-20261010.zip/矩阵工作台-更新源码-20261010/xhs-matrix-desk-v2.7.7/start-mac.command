#!/bin/bash
# 小红书矩阵工作台 · Mac 双击启动
# 首次双击会自动安装环境（约几分钟），之后直接启动软件。
cd "$(dirname "$0")"
if [ ! -x "venv/bin/python" ]; then
  echo "首次运行，正在安装环境（约需几分钟，请保持网络畅通）…"
  bash setup.sh || { echo "安装失败，请截图发回"; exit 1; }
fi
./venv/bin/python run.py
