@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================
echo  小红书矩阵工作台 - 正在启动
echo ============================================
if not exist "venv\Scripts\python.exe" (
    echo 首次运行，需要先安装环境（约几分钟，请勿关闭窗口）…
    echo.
    call setup.bat
    if not exist "venv\Scripts\python.exe" (
        echo.
        echo [失败] 环境安装未完成，请截图本窗口发回。
        pause
        exit /b 1
    )
)
echo 正在启动软件…
venv\Scripts\python run.py
echo.
echo 程序已退出（上面的红色文字是报错信息，没有则为正常退出）。
pause
